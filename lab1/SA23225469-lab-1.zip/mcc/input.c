a = 5;
b = a + 2 * 5;
print(b)