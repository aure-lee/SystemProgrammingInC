#include <stdio.h>
#include <stdlib.h>
#include "stack-server.h"

#define TODO()\
do{\
    extern int printf(char *, ...);\
    printf("Add your code here: file %s, line %d\n", __FILE__, __LINE__);\
}while(0)




stack_t stack;

void stack_init(){
// Exercise:
// Add your code here:
TODO();

    return;
}

void stack_push(int value){
    // Exercise:
    // Add your code here:
    TODO();

}

int stack_pop(){
    int value = -1;
    // Exercise:
    // Add your code here:
    TODO();

    return value;
}

int stack_size(){
    int size = 0;
    // Exercise:
    // Add your code here:
    TODO();

    return size;
}
