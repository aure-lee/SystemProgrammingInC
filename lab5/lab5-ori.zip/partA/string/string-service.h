#ifndef STRING_COUNT_H
#define STRING_COUNT_H

#define TODO()\
do{\
    extern int printf(char *, ...);\
    printf("Add your code here: file %s, line %d\n", __FILE__, __LINE__);\
}while(0)




int CountString(char* str);

#endif

